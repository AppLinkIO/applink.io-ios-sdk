# AppLinkIO

[![CI Status](http://img.shields.io/travis/ahass0227/AppLinkIO.svg?style=flat)](https://travis-ci.org/ahass0227/AppLinkIO)
[![Version](https://img.shields.io/cocoapods/v/AppLinkIO.svg?style=flat)](http://cocoapods.org/pods/AppLinkIO)
[![License](https://img.shields.io/cocoapods/l/AppLinkIO.svg?style=flat)](http://cocoapods.org/pods/AppLinkIO)
[![Platform](https://img.shields.io/cocoapods/p/AppLinkIO.svg?style=flat)](http://cocoapods.org/pods/AppLinkIO)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

AppLinkIO is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'AppLinkIO'
```

## Author

AppLink.io, Inc. - support@applink.io

## License

AppLinkIO is available under the Commercial license. See the LICENSE file for more info.
